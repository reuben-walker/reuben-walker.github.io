# Program: Assignment 1 - Forestry Leading Species Report 
# Filename: assmt1_forestry_species_report.py
# Author: Reuben Walker
# Purpose: to provide summarized data about all forest stands of a given
#   leading species, as selected by the user.

# Main function definition (makes looping easier)
def main():
    # Select all forest polygons in the layer and create an empty list of species
    layer = iface.activeLayer()
    layer.selectByExpression('"SP1" IS NOT NULL', QgsVectorLayer.SetSelection)
    selection = layer.selectedFeatures()
    speciesList = []

    # Go through each entry and add unique species to the list
    for feature in selection:
        if feature['SP1'] not in speciesList:
            speciesList.append(feature['SP1'])

    # Create a list of numeric options for user to choose from        
    optionList = ''
    for i in range(len(speciesList)):
        optionList = optionList + ("%d. %s\n" % (i+1,speciesList[i]))
    
    # Set up QInputDialog
    qid = QInputDialog()
    title = "Select a tree species (enter the number): "
    label = optionList
    mode = QLineEdit.Normal
    default = ""

    # Prompt user for input, returning an error and re-prompting the user
    #   if they enter a non-numeric input or out of range value
    validInput = False
    while validInput == False:
        optionSelect, ok = QInputDialog.getText(qid,title,label,mode,default)
        if ok == False:
            optionSelect = '1'
            break
        # Error handler if user enters a non-numeric input
        try:
            # Check if user input is in range
            if int(optionSelect) <= 0 or int(optionSelect) > len(speciesList):
                iface.messageBar().pushMessage("Error", "You entered an invalid input. Please enter a number that corresponds to one of the list items.", level=Qgis.Warning)
                validInput = False
            else:
                validInput = True
                iface.messageBar().clearWidgets()
        except:
            iface.messageBar().pushMessage("Error", "You entered an invalid input. Please enter a number that corresponds to one of the list items.", level=Qgis.Warning)
            validInput = False

    # Select appropriate forest stand polygons based on user input
    expr = "\"SP1\" = '%s'" % (speciesList[int(optionSelect)-1])
    layer.selectByExpression(expr, QgsVectorLayer.SetSelection)
    selection = layer.selectedFeatures()

    # Create a list containing all areas of the selected polygons
    # as well as the average leading species percentage for polygons
    areas = []
    leadSpeciesPercentage = 0
    for feature in selection:
        areas.append(feature['SHAPE_Area'])
        leadSpeciesPercentage += feature['SP1P']
    leadSpeciesPercentage = leadSpeciesPercentage/float(len(areas))

    # Print final results
    if ok == True:
        print("\n=========== RESULTS FOR SELECTED SPECIES: %2s =============" % (speciesList[int(optionSelect)-1]))
        print("Number of polygons of this species: %16i" % len(areas))
        print("Smallest area stand of this species: %18.2f" % min(areas)+ " m\u00B2")
        print("Largest area stand of this species: %19.2f" % max(areas)+ " m\u00B2")
        print("Avg. leading species percentage within stands: %8.2f" % (leadSpeciesPercentage) + ' %')
        print("Avg. area of stands of this species: %18.2f" % (sum(areas)/(float(len(areas))))+ " m\u00B2")
        print("Total area of stands of this species: %17.2f" % sum(areas) + " m\u00B2")

# Loop to run the main function as many times as the user wants.
#   User will be asked if they want to continue. If they enter
#   an invalid value, the program will also end
userContinue = '1'
while userContinue == '1':
    main()
    qid = QInputDialog()
    title = "Run again?: "
    label = '1. Yes\n2. No'
    mode = QLineEdit.Normal
    default = ""
    userContinue, ok = QInputDialog.getText(qid,title,label,mode,default)
    if userContinue.lower() == 'y' or userContinue.lower() == 'yes':
        userContinue = '1'
